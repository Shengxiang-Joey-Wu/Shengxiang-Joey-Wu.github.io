%% This script is used to simulate the cyclic voltammetry for one
% electron transfer and reversible reactions

%% Contributor: Shengxiang Wu
% Date: 2022-09-23

%% clear workspace and close all figures
clc
clear all
close all

%% Import physical constant
phc = fundamentalPhysicalConstantsFromNIST();
c = phc.speed_of_light_in_vacuum.value; % Speed of light
h = phc.Planck_constant.value; % Planck constant
hbar = phc.Planck_constant_over2pi.value; % Redued Planck constant
eV = phc.electron_volt.value; % Electron volt
m = phc.electron_mass.value; % Electron mass
Bohr_radius = phc.Bohr_radius.value; % Bohr radius
NA = phc.Avogadro_constant.value; % Avogadro constant
hartree = phc.atomic_unit_of_energy.value; % hartree: atomic unit of energy
atomic_time = phc.atomic_unit_of_time.value; % atomic unit of time
atomic_Efield = phc.atomic_unit_of_electric_field.value; % atomic unit of electric field
epsilon_naught = phc.electric_constant.value; % electric constant
kb = phc.Boltzmann_constant.value; % Boltzmann constant
Angstrom = phc.Angstrom_star.value; % Angstrom
F = phc.Faraday_constant.value; % Faraday constant
R = phc.molar_gas_constant.value; % Molar gas constant

%% define variables and assign values
scan_rate = 0.04; % potential scan rate in CV, in V/s

E0 = 0; % formal potential, in V
n = 2; % number of electron transfer
Cox_bulk = 6.1 .* 10 .^ -8; % concentration of Ox specied, in mol/cm^-3
D = 1 .* 10 .^ -5;% diffusion coefficients, in cm^2/s
k_naught = 1; % standard rate constant for electron transfer, in cm/s
alpha = 0.5; % Transfer coefficient for redox couple, unitless
Temp = 300; % temperature, in K

potential_range = 0.5; % the difference between highest and lowest potential, in V
t_total = 2 .* potential_range ./ scan_rate; % total time required to perform a CV

delta_V = 0.005; % during CV sweep
delta_t = delta_V ./ scan_rate; % corresponding time discrements

potential_probed_f = 0.2:(-delta_V):-0.3; % forward scan from high potential to low potential
potential_probed_b = -0.3:(delta_V):0.2; % backward scan
potential_probed = [potential_probed_f, potential_probed_b(2:length(potential_probed_b))];


x_total = 6 .* (D .* t_total) .^ 0.5; % total distance, in cm
delta_x = 2 .* 10 .^ -3; % distance step, in cm.  
num_x = ceil(x_total ./ delta_x); % number of x increments

% using two list to create the 2D grids
t_list = 0:delta_t:t_total;
x_list = 0:delta_x:(num_x .* delta_x);

%% calculation begins
% create 2D grid of concentration
Cox_2D = NaN(length(t_list), length(x_list));
Cred_2D = NaN(length(t_list), length(x_list));

Cox_2D(1, 2:length(x_list)) = Cox_bulk;
Cox_2D(:, length(x_list)) = Cox_bulk;
Cred_2D(1, 2:length(x_list)) = 0;
Cred_2D(:, length(x_list)) = 0;

% lambda is created for convenience
lambda = D .* delta_t ./ delta_x .^ 2;

i_list = zeros(length(t_list), 1);
for index_t = 1:length(t_list)
    % the potential at the working electrode vs. formal potential
    my_V = potential_probed(index_t); 

    % forward rate constant
    kf = k_naught .* exp(-alpha .* n .* F .* (my_V - E0) ./ (R .* Temp));
    
    % backward rate constant
    kb = k_naught .* exp((1 - alpha) .* n .* F .* (my_V - E0) ./ (R .* Temp));

    Jox = -(kf .* Cox_2D(index_t, 2) - kb .* Cred_2D(index_t, 2)) ./ (1 + kf .* delta_x ./ D + kb .* delta_x ./ D);
    Jred = -Jox;
    
    i_list(index_t) = -n .* Jox;

    % the concentration of Ox species at electrode surface at this time (potential)
    Cox_2D(index_t, 1) = Cox_2D(index_t, 2) + Jox .* delta_x ./ D;
    Cred_2D(index_t, 1) = Cred_2D(index_t, 2) + Jred .* delta_x ./ D;
    
    for index_x = 2:(length(x_list) - 1)
        if index_t < length(t_list)
            Cox_2D(index_t + 1, index_x) = Cox_2D(index_t, index_x) + ...
                lambda .* (Cox_2D(index_t, index_x - 1) - 2 .* Cox_2D(index_t, index_x) + Cox_2D(index_t, index_x + 1));

            Cred_2D(index_t + 1, index_x) = Cred_2D(index_t, index_x) + ...
                lambda .* (Cred_2D(index_t, index_x - 1) - 2 .* Cred_2D(index_t, index_x) + Cred_2D(index_t, index_x + 1));
        end
    end

end

%% making figures
% figure
% plot(potential_probed, i_list)
% set(gca, 'xdir', 'reverse')
